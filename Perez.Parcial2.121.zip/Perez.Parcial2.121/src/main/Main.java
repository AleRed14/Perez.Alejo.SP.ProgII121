package main;

import config.AppConfig;
import enums.Genero;
import java.io.IOException;
import java.util.Comparator;
import model.Catalogo;
import model.Pelicula;

public class Main {

    public static void main(String[] args) {
        try {
// Crear un catálogo de películas
            Catalogo<Pelicula> catalogoPeliculas = new Catalogo<>();
            catalogoPeliculas.agregar(new Pelicula(1, "El Padrino", "Francis Ford Coppola", Genero.DRAMA));
catalogoPeliculas.agregar(new Pelicula(2, "La La Land", "Damien Chazelle",
                    Genero.COMEDIA));
            catalogoPeliculas.agregar(new Pelicula(3, "Guerra Mundial Z", "Marc Forster", Genero.TERROR));
catalogoPeliculas.agregar(new Pelicula(4, "Toy Story", "John Lasseter",
                    Genero.ANIMACION));
            catalogoPeliculas.agregar(new Pelicula(5, "The Social Dilemma", "Jeff Orlowski", Genero.DOCUMENTAL));
// Mostrar todas las películas en el catálogo
System.out.println("Catálogo de películas:");
            catalogoPeliculas.paraCadaElemento(p -> System.out.println(p));
// Filtrar películas por género COMEDIA
            System.out.println("\nPelículas de género COMEDIA:");
            catalogoPeliculas.filtrar(p -> p.getGenero() == Genero.COMEDIA).forEach(p -> System.out.println(p));
// Filtrar películas cuyo título contiene "Guerra"
            System.out.println("\nPelículas cuyo título contiene 'Guerra':");
            catalogoPeliculas.filtrar(p -> p.getTitulo().contains("Guerra")).forEach(p -> System.out.println(p));
// Ordenar películas de manera natural (por id)
            System.out.println("\nPelículas ordenadas de manera natural (por id):");
            catalogoPeliculas.ordenar();
            catalogoPeliculas.paraCadaElemento(p -> System.out.println(p));
// Ordenar películas por título usando Comparator
            System.out.println("\nPelículas ordenadas por título:");
            catalogoPeliculas.ordenar((p1, p2) -> p1.getTitulo().compareTo(p2.getTitulo()));
            catalogoPeliculas.paraCadaElemento(p -> System.out.println(p));
            // Guardar el catálogo en archivo binario
            catalogoPeliculas.guardarEnArchivo(AppConfig.getRutaBinarioString());
            // Cargar el catálogo desde archivo binario
            
            Catalogo<Pelicula> catalogoCargado = new Catalogo<>();
            catalogoCargado.cargarDesdeArchivo(AppConfig.getRutaBinarioString());
            System.out.println("\nPelículas cargadas desde archivo binario:");
            catalogoCargado.paraCadaElemento(p -> System.out.println(p));
            // Guardar el catálogo en archivo CSV
            catalogoPeliculas.guardarEnCSV(AppConfig.getRutaCSVString());
            // Cargar el catálogo desde archivo CSV
            catalogoCargado.cargarDesdeCSV(AppConfig.getRutaCSVString(),l -> Pelicula.fromCSV(l));
            System.out.println("\nPelículas cargadas desde archivo CSV:");
            catalogoCargado.paraCadaElemento(p -> System.out.println(p));
        } catch (RuntimeException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
