package enums;

public enum Genero {

    ACCION,
    DRAMA,
    COMEDIA,
    DOCUMENTAL,
    TERROR,
    ANIMACION;

}
