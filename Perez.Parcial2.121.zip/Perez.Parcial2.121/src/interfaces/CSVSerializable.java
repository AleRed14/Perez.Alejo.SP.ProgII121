package interfaces;

public interface CSVSerializable<T> extends Comparable<T>{
    String toCSV();
    
    String toCSVHeader();
}
