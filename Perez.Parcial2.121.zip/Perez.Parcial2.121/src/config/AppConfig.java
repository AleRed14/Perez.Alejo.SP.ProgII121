package config;

import java.nio.file.Path;
import java.nio.file.Paths;

public class AppConfig {
    private static final String BASE = "src/data/";
    
    public static Path getRutaCSV(){
        return Paths.get(BASE, "pelicuas.csv");
    }
    
    public static Path getRutaBinario(){
        return Paths.get(BASE, "peliculas.dat");
    }
    
    public static String getRutaCSVString(){
        return getRutaCSV().toString();
    }
    
    public static String getRutaBinarioString(){
        return getRutaBinario().toString();
    }
}
