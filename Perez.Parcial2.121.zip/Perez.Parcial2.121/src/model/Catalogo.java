package model;

import interfaces.CSVSerializable;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import model.Pelicula;

public class Catalogo<T extends CSVSerializable>{
    
    private List<T> items = new ArrayList<>();
    
    public void agregar(T item){
        validarItem(item);
        items.add(item);
    }
    
    
    public void eliminarPorIndice(int indice) {
        validarIndice(indice);
        items.remove(indice);
    }

    
    public boolean eliminar(T item) {
        validarItem(item);
        if (items.contains(item)) {
            return items.remove(item);
        }
        return false;
    }
    
    public T obtener(int indice){
        validarIndice(indice);
        return items.get(indice);
    }
    
    public int tamanio() {
        return items.size();
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> toReturn = new ArrayList<>();

        for (T item : items) {
            if (criterio.test(item)) {
                toReturn.add(item);
            }
        }

        return toReturn;
    }
    
    public void ordenar() {
        
        items.sort((e1, e2) -> e1.compareTo(e2));
    }

    public void ordenar(Comparator<? super T> comparator) {
        items.sort(comparator);
    }
    
    public void guardarEnCSV(String path) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write(items.get(0).toCSVHeader() + "\n");
            for (T item : items) {
                bw.write(item.toCSV() + "\n");
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    public void cargarDesdeCSV(String path, Function<String, T> constructor) {
        List<T> toReturn = new ArrayList<>();

        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            String linea;
            bf.readLine();
            while ((linea = bf.readLine()) != null) {

                T item = constructor.apply(linea);
                toReturn.add(item);
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        items = toReturn;
    }
    
    public void guardarEnArchivo(String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(this.items);
            System.out.println("Serializacion exitosa.");

        } catch (IOException ex) {
            System.out.println("Problema al serializar: ");
            System.out.println(ex.getMessage());
        }
    }
    
    public void cargarDesdeArchivo(String path) {
        List<T> toReturn = null;
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {

            toReturn = (List<T>) entrada.readObject();
            System.out.println("Lectura binaria exitosa");
        } catch (ClassNotFoundException | IOException ex) {
            System.out.println("Error al leer");
            System.out.println(ex.getMessage());
        }
        items = toReturn;
    }
    
    public void paraCadaElemento(Consumer<T> operacion){
        for(T item : items){
            operacion.accept(item);
        }
    }
    
    public void validarIndice(int indice){
        if (indice < 0 || indice >= tamanio()) {
            throw new IndexOutOfBoundsException("Numero negativo o fuera de rango");
        }
    }
    
    
    public void validarItem(T item) {
        if (item == null) {
            throw new NullPointerException();
        }
    }
}
