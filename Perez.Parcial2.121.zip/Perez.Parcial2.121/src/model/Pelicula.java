package model;

import enums.Genero;
import interfaces.CSVSerializable;
import java.io.Serializable;

public class Pelicula implements Serializable, CSVSerializable {
    private static final long serialVersionUID = 1L;
    private int id;
    private String titulo;
    private String director;
    private Genero genero;

    public Pelicula(int id, String titulo, String director, Genero genero) {
        this.id = id;
        this.titulo = titulo;
        this.director = director;
        this.genero = genero;
    }
    
    
    public static Pelicula fromCSV(String peliculaCSV){
        Pelicula toReturn = null;
        
        if(peliculaCSV.endsWith("\n")){
            peliculaCSV = peliculaCSV.substring(peliculaCSV.length() - 1);
        }
        
        String [] values = peliculaCSV.split(",");
        
        if(values.length == 4){
            int id = Integer.parseInt(values[0]);
            String titulo = values[1];
            String director = values[2];
            Genero genero = Genero.valueOf(values[3]);
            toReturn = new Pelicula(id, titulo, director, genero);
        }
        
        return toReturn;
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + director + "," + genero;
    }
    
    @Override
    public String toCSVHeader(){
        return "id,titulo,director,genero";
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDirector() {
        return director;
    }

    public Genero getGenero() {
        return genero;
    }

    
    
    @Override
    public String toString() {
        return "Pelicula{" + "id=" + id + ", titulo=" + titulo + ", director=" + director + ", genero=" + genero + '}';
    }

    @Override
    public int compareTo(Object o) {
        if(o instanceof Pelicula p){
            return Integer.compare(id, p.id);    
            
        }
        return 0;
    }
    
    
}
